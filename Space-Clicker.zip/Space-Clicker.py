'''Accesses pygame files.'''
import pygame  
'''To communicate with windows.'''
import sys  
'''Generate sudo random numbers.'''
import random


'''Game Setup.'''

'''Starts game engine.'''
pygame.init() 
'''Gets all system fonts.'''
pygame.font.get_fonts()
'''Creates clock to limit frames per second.'''
clock = pygame.time.Clock()  
'''Sets max speed of main loop.'''
FPS = 60 
'''Sets size of  main window.'''
SCREENSIZE = SCREENWIDTH, SCREENHEIGHT = 1000, 800
'''Creates main display window.'''
screen = pygame.display.set_mode(SCREENSIZE) 

########################################################

'''Set variables for colors RGB (0-255).'''
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
yellow = (255, 255, 0)
green = (0, 255, 0)

'''Set variables for Blit.'''
'''Sets int for scale variables.'''
P1scale = 65
P2scale = 85,115
BGscale = (1000,800)

'''Sets int for target size variable.'''
targetsize = 30
'''Assigns sound file with variable.'''
hit = pygame.mixer.Sound(r'hitmarker.mp3')

#######################################################

font1 = pygame.font.Font('C:\Windows\Fonts\Cambria.ttc', 50)

font = pygame.font.Font.render(font1, 'Space-Clicker', True, white)

'''Loads image into player1Img variable and changes size to scale variable.'''
player1Img = pygame.transform.scale(
    pygame.image.load('sprite.png'),(P1scale,P1scale) 
)

background = pygame.transform.scale(
    pygame.image.load('space.png'),((BGscale[0],BGscale[1]))
)

player2Img = pygame.transform.scale(
    pygame.image.load('planet.png'),(P2scale[0],P2scale[1])
)


'''Makes cursor invisible.'''
pygame.mouse.set_visible(False)

'''Sets target origin location in list index 0 (x)m index 1 (y).'''
targetXY = [250,250] 

'''Firelock control variable.'''
firelock = 0

'''Variable used to close the game if it changes to anything other than 'running'.'''
gameState = "running" 

'''While loop.'''
while gameState != "exit": 
        
        # Events #

    '''Get user interation events.'''    
    for event in pygame.event.get(): 

        '''Tests if window's X (close) has been clicked.'''
        if event.type == pygame.QUIT:

            '''Causes exit of game loop.'''  
            gameState = "exit" 

        '''Checks for mouse button up and sets firelock to 0 if true.'''
        if event.type == pygame.MOUSEBUTTONUP: 
            firelock = 0
        
     
        # Blit #
        
        '''Fills screen with black colour.'''
        screen.fill(black)
        '''Gets mouse x and y positions and stores it in mousePosition variable.'''
        mousePosition = pygame.mouse.get_pos() 
        
        '''Grabs index in the 1st position (x axis) assigns to newxpos
           variable after subtracting scale variable divided by 2.'''
        newxpos = mousePosition[0] - P1scale / 2 

        '''Grabs index in the 2nd position (y axis) assigns to newypos
           variable after subtracting scale variable divided by 2.'''                         
        newypos = mousePosition[1] - P1scale / 2 

        player1xy = newxpos, newypos

        '''Displays blit information displaying screen onto the main display.'''
        player1 = screen.blit(player1Img,player1xy) 

        screen.blit(background,(0,0))

        screen.blit(font,(425,50))



        
        
        # Collision #
        
        target = screen.blit(player2Img,targetXY)
        if player1.colliderect(target):                   
            '''Checks if first mouse button is pressed and firelock variable is 0,
               Sets firelock variable to 1, this will stop the following 3 lines from occuring until the mouse button is
               released which causes the firelock variable revert back to 0 (See lines 91, 92) '''
            if pygame.mouse.get_pressed()[0] == True and firelock == 0:
                firelock = 1 
                pygame.mixer.Sound.play(hit)
                '''Gives a random number between 0 and 1000 to the first element in the targetXY list (x).'''
                targetXY[0] = random.randint(0, SCREENWIDTH - 115) 
                '''Gives a random number between 0 and 800 to the second element in the target XY list (y).'''
                targetXY[1] = random.randint(0, SCREENHEIGHT - 85) 
        '''Redraws player sprite to appear on   top of target sprite.'''
        screen.blit(player1Img,player1xy)          

    
    '''transfers build screen to human visable screen.'''
    pygame.display.flip()
    '''limits game to frame per second, FPS value.'''
    clock.tick(FPS)  

# out of game loop #

'''Notifies user the game has ended.'''
print("The game has closed")

'''Stops the game engine.'''
pygame.quit() 

'''Close operating system window.'''
sys.exit() 
